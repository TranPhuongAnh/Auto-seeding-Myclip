1. Thực hiện cài đặt trước khi chạy tool theo file hướng dẫn đi kèm trong folder Pre_Run_Tool
2. File run.bat là file chạy tool 1 lần
3. File schedulerOn.bat là file tạo tiến trình chạy tool mỗi 5 phút 1 lần
4. File schedulerOff.bat là file tắt tiến trình chạy tool của file schedulerOn.bat